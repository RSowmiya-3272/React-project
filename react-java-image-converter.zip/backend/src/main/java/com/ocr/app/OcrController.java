package com.ocr.app;

import net.sourceforge.tess4j.TesseractException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/ocr")
public class OcrController {

    private final OcrService ocrService;

    public OcrController(OcrService ocrService) {
        this.ocrService = ocrService;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestParam("image") MultipartFile image) {
        try {
            String text = ocrService.extractText(image);
            return ResponseEntity.ok(new OcrResponse(text));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(new ApiError(e.getMessage()));
        } catch (IOException | TesseractException e) {
            return ResponseEntity.internalServerError().body(new ApiError("OCR failed: " + e.getMessage()));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("OK");
    }

    public static class ApiError {
        private final String error;

        public ApiError(String error) {
            this.error = error;
        }

        public String getError() {
            return error;
        }
    }
}
