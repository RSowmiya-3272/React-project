package com.ocr.app;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class OcrService {

    @Value("${tessdata.path:}")
    private String configuredTessdataPath;

    public String extractText(MultipartFile file) throws IOException, TesseractException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("No image file provided");
        }

        // Save uploaded file to a temporary location.
        Path tempFile = Files.createTempFile("ocr-upload-", "-" + file.getOriginalFilename());
        try {
            file.transferTo(tempFile.toFile());

            Tesseract tesseract = new Tesseract();
            tesseract.setDatapath(resolveTessdataPath());
            tesseract.setLanguage("eng");
            tesseract.setTessVariable("user_defined_dpi", "300");

            return tesseract.doOCR(tempFile.toFile()).trim();
        } finally {
            try {
                Files.deleteIfExists(tempFile);
            } catch (IOException ignored) {
                // best-effort cleanup
            }
        }
    }

    private String resolveTessdataPath() {
        // 1. Explicit environment variable used by Tesseract itself.
        String env = System.getenv("TESSDATA_PREFIX");
        if (env != null && !env.isBlank()) {
            return stripTrailingSlash(env);
        }

        // 2. Value configured in application.properties.
        if (configuredTessdataPath != null && !configuredTessdataPath.isBlank()) {
            return stripTrailingSlash(configuredTessdataPath);
        }

        // 3. Common system locations.
        String[] candidates = {
                "/usr/share/tesseract-ocr/4.00/tessdata",
                "/usr/share/tesseract-ocr/5/tessdata",
                "/usr/share/tessdata",
                "C:\\Program Files\\Tesseract-OCR\\tessdata",
                "C:\\Program Files (x86)\\Tesseract-OCR\\tessdata",
                "tessdata"
        };
        for (String candidate : candidates) {
            if (java.nio.file.Files.isDirectory(java.nio.file.Paths.get(candidate))) {
                return candidate;
            }
        }

        // Fallback; will likely fail at runtime unless the folder is created.
        return "tessdata";
    }

    private String stripTrailingSlash(String path) {
        if (path.endsWith("/") || path.endsWith("\\")) {
            return path.substring(0, path.length() - 1);
        }
        return path;
    }
}
