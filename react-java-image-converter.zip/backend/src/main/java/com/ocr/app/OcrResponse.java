package com.ocr.app;

public class OcrResponse {
    private final String text;

    public OcrResponse(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
