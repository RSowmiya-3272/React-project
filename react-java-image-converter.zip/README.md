# Image-to-Text Converter

A React + Vite + Tailwind CSS frontend for converting images to text, with an optional Java Spring Boot backend powered by [Tess4J](https://github.com/nguyenq/tess4j).

## Features

- Drag-and-drop or click-to-upload image selection
- Browser-based OCR using [Tesseract.js](https://github.com/naptha/tesseract.js)
- Optional Java backend OCR using Spring Boot + Tesseract
- Custom dark/violet/fuchsia/cyan color theme
- Copy and download extracted text
- Language selection for browser OCR
- Responsive layout

## Project structure

```
.
├── index.html
├── package.json
├── src/
│   ├── App.tsx           # Main React application
│   ├── index.css         # Tailwind + custom theme styles
│   ├── main.tsx          # React entry point
│   └── vite-env.d.ts     # Vite env types
└── backend/              # Java Spring Boot OCR service
    ├── pom.xml
    └── src/main/java/com/ocr/app/
        ├── OcrApplication.java
        ├── OcrController.java
        ├── OcrResponse.java
        ├── OcrService.java
        └── WebConfig.java
```

## Frontend

### Install dependencies

```bash
npm install
```

### Run locally

```bash
npm run dev
```

### Build

```bash
npm run build
```

### Environment variables

You can point the frontend at the Java backend by creating a `.env` file in the project root:

```env
VITE_OCR_API_URL=http://localhost:8080/api/ocr/upload
```

## Java Backend (optional)

### Requirements

- JDK 17+
- Maven 3.8+
- Tesseract language data (`tessdata` directory). Download from:
  - Ubuntu/Debian: `sudo apt install tesseract-ocr-eng`
  - macOS: `brew install tesseract`
  - Windows: install from [Tesseract at UB Mannheim](https://github.com/UB-Mannheim/tesseract/wiki)

### Configure tessdata

The backend looks for traineddata files in this order:

1. `TESSDATA_PREFIX` environment variable
2. `tessdata.path` in `application.properties`
3. Common system locations (Linux, macOS, Windows)
4. A `tessdata` folder next to the JAR

### Run backend

```bash
cd backend
mvn spring-boot:run
```

The API will be available at `http://localhost:8080/api/ocr/upload`.

### Test with curl

```bash
curl -F "image=@sample.png" http://localhost:8080/api/ocr/upload
```

## License

MIT
