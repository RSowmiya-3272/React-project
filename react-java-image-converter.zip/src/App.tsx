import { useState, useRef, useCallback } from "react";
import Tesseract from "tesseract.js";

interface OcrProgress {
  status: string;
  progress: number;
}

const API_URL = import.meta.env.VITE_OCR_API_URL || "http://localhost:8080/api/ocr/upload";

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [text, setText] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState<OcrProgress>({ status: "", progress: 0 });
  const [error, setError] = useState<string>("");
  const [useBackend, setUseBackend] = useState(false);
  const [backendUrl, setBackendUrl] = useState(API_URL);
  const [language, setLanguage] = useState("eng");
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = useCallback(() => {
    if (preview) URL.revokeObjectURL(preview);
    setFile(null);
    setPreview("");
    setText("");
    setError("");
    setProgress({ status: "", progress: 0 });
    if (inputRef.current) inputRef.current.value = "";
  }, [preview]);

  const handleFile = useCallback(
    (selected: File | null) => {
      if (!selected) return;
      if (!selected.type.startsWith("image/")) {
        setError("Please select a valid image file (JPG, PNG, GIF, WEBP).");
        return;
      }
      if (selected.size > 10 * 1024 * 1024) {
        setError("Image size should be less than 10MB.");
        return;
      }
      setError("");
      if (preview) URL.revokeObjectURL(preview);
      setFile(selected);
      setPreview(URL.createObjectURL(selected));
      setText("");
      setProgress({ status: "", progress: 0 });
    },
    [preview]
  );

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const onDragLeave = () => setIsDragging(false);
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const extractWithBackend = async (): Promise<string> => {
    if (!file) throw new Error("No image selected.");
    const formData = new FormData();
    formData.append("image", file);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    try {
      const res = await fetch(backendUrl, {
        method: "POST",
        body: formData,
        signal: controller.signal,
      });
      clearTimeout(timeout);
      if (!res.ok) {
        const err = await res.text();
        throw new Error(err || `Server responded with ${res.status}`);
      }
      const data = await res.json();
      return data.text || data || "";
    } catch (err) {
      clearTimeout(timeout);
      throw err;
    }
  };

  const extractWithBrowser = async (): Promise<string> => {
    if (!file) throw new Error("No image selected.");
    const result = await Tesseract.recognize(file, language, {
      logger: (m) => {
        if ("status" in m && "progress" in m) {
          setProgress({ status: m.status, progress: m.progress });
        }
      },
    });
    return result.data.text;
  };

  const handleExtract = async () => {
    if (!file) {
      setError("Please upload an image first.");
      return;
    }
    setLoading(true);
    setError("");
    setText("");
    try {
      const extracted = useBackend ? await extractWithBackend() : await extractWithBrowser();
      setText(extracted.trim());
      setProgress({ status: "done", progress: 1 });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unexpected error";
      setError(
        useBackend
          ? `Backend OCR failed: ${message}. Make sure the Java backend is running and CORS is enabled, or switch to Browser OCR.`
          : `OCR failed: ${message}. Please try a clearer image.`
      );
    } finally {
      setLoading(false);
    }
  };

  const copyText = async () => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      setError("Unable to copy to clipboard.");
    }
  };

  const downloadText = () => {
    if (!text) return;
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `extracted-text-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen w-full px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        {/* Header */}
        <header className="mb-10 text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-500 shadow-lg shadow-fuchsia-500/30">
            <svg
              className="h-8 w-8 text-white"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <path d="M3 9h18" />
              <path d="M9 21V9" />
              <path d="M14 15h2" />
              <path d="M14 11h2" />
              <path d="M6 15h.01" />
              <path d="M6 11h.01" />
            </svg>
          </div>
          <h1 className="mb-2 text-4xl font-extrabold tracking-tight sm:text-5xl">
            <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent animate-gradient">
              Image to Text
            </span>{" "}
            Converter
          </h1>
          <p className="mx-auto max-w-xl text-slate-300">
            Upload any image and instantly extract editable text using the browser OCR engine or your own Java backend.
          </p>
        </header>

        {/* Main Card */}
        <main className="glass rounded-3xl p-6 shadow-2xl sm:p-10">
          {/* Controls */}
          <div className="mb-8 flex flex-col gap-4 rounded-2xl border border-white/10 bg-white/5 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <label htmlFor="engine" className="text-sm font-medium text-slate-200">
                OCR Engine
              </label>
              <select
                id="engine"
                value={useBackend ? "backend" : "browser"}
                onChange={(e) => setUseBackend(e.target.value === "backend")}
                className="rounded-lg border border-white/10 bg-slate-900/80 px-3 py-2 text-sm text-white outline-none ring-cyan-500 focus:ring-2"
              >
                <option value="browser">Browser (Tesseract.js)</option>
                <option value="backend">Java Backend</option>
              </select>
            </div>

            {!useBackend && (
              <div className="flex items-center gap-3">
                <label htmlFor="lang" className="text-sm font-medium text-slate-200">
                  Language
                </label>
                <select
                  id="lang"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="rounded-lg border border-white/10 bg-slate-900/80 px-3 py-2 text-sm text-white outline-none ring-cyan-500 focus:ring-2"
                >
                  <option value="eng">English</option>
                  <option value="spa">Spanish</option>
                  <option value="fra">French</option>
                  <option value="deu">German</option>
                  <option value="ita">Italian</option>
                  <option value="por">Portuguese</option>
                  <option value="rus">Russian</option>
                  <option value="chi_sim">Chinese (Simplified)</option>
                  <option value="jpn">Japanese</option>
                  <option value="kor">Korean</option>
                </select>
              </div>
            )}

            {useBackend && (
              <div className="flex flex-1 items-center gap-3 sm:justify-end">
                <label htmlFor="api" className="text-sm font-medium text-slate-200">
                  API URL
                </label>
                <input
                  id="api"
                  type="text"
                  value={backendUrl}
                  onChange={(e) => setBackendUrl(e.target.value)}
                  className="w-full max-w-sm rounded-lg border border-white/10 bg-slate-900/80 px-3 py-2 text-sm text-white outline-none ring-cyan-500 focus:ring-2 sm:w-auto"
                  placeholder="http://localhost:8080/api/ocr/upload"
                />
              </div>
            )}
          </div>

          {/* Upload */}
          <div
            onClick={() => inputRef.current?.click()}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
            className={`group cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all duration-300 sm:p-12 ${
              isDragging
                ? "drop-active"
                : "border-violet-400/40 bg-white/[0.03] hover:border-cyan-400 hover:bg-cyan-400/5"
            }`}
          >
            <input
              ref={inputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0] || null)}
            />
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-violet-500/20 to-cyan-500/20 ring-1 ring-white/10 group-hover:ring-cyan-400/40">
              <svg
                className="h-7 w-7 text-cyan-300"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
            </div>
            <p className="text-lg font-medium text-white">
              {isDragging ? "Drop the image here" : "Drag & drop an image or click to browse"}
            </p>
            <p className="mt-1 text-sm text-slate-400">Supports JPG, PNG, GIF, WEBP up to 10MB</p>
          </div>

          {/* Preview */}
          {preview && (
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:items-start">
              <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black/20 p-2">
                <img
                  src={preview}
                  alt="Preview"
                  className="max-h-64 w-auto rounded-xl object-contain"
                />
              </div>
              <div className="flex flex-col gap-3 sm:ml-auto">
                <button
                  onClick={reset}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/10"
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  Clear Image
                </button>
                <button
                  onClick={handleExtract}
                  disabled={loading}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-500 px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-fuchsia-500/25 transition hover:scale-[1.02] hover:shadow-fuchsia-500/40 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loading ? (
                    <>
                      <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                        />
                      </svg>
                      Extracting…
                    </>
                  ) : (
                    <>
                      <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      Extract Text
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Progress */}
          {loading && !useBackend && (
            <div className="mt-8">
              <div className="mb-2 flex items-center justify-between text-sm text-slate-300">
                <span className="capitalize">{progress.status.replace(/_/g, " ") || "Initializing"}</span>
                <span>{Math.round(progress.progress * 100)}%</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-500 transition-all duration-300"
                  style={{ width: `${Math.round(progress.progress * 100)}%` }}
                />
              </div>
            </div>
          )}

          {loading && useBackend && (
            <div className="mt-8 text-center text-sm text-slate-300">
              <span className="inline-flex items-center gap-2">
                <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Waiting for Java backend…
              </span>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="mt-8 flex items-start gap-3 rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-red-200">
              <svg className="mt-0.5 h-5 w-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <p className="text-sm">{error}</p>
            </div>
          )}

          {/* Output */}
          {text && (
            <div className="mt-8">
              <div className="mb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <h2 className="text-lg font-semibold text-white">Extracted Text</h2>
                <div className="flex gap-3">
                  <button
                    onClick={copyText}
                    className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 text-sm text-slate-200 transition hover:bg-white/10"
                  >
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                      <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" />
                    </svg>
                    Copy
                  </button>
                  <button
                    onClick={downloadText}
                    className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 text-sm text-slate-200 transition hover:bg-white/10"
                  >
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="7 10 12 15 17 10" />
                      <line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                    Download
                  </button>
                </div>
              </div>
              <textarea
                readOnly
                value={text}
                className="custom-scroll min-h-[12rem] w-full resize-y rounded-2xl border border-white/10 bg-black/30 p-4 font-mono text-sm leading-relaxed text-slate-200 outline-none ring-cyan-500 focus:ring-2"
              />
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="mt-10 text-center text-sm text-slate-400">
          <p>
            Powered by{" "}
            <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text font-medium text-transparent">
              Tesseract.js
            </span>{" "}
            in the browser, with an optional{" "}
            <span className="bg-gradient-to-r from-fuchsia-400 to-cyan-400 bg-clip-text font-medium text-transparent">
              Java + Spring Boot
            </span>{" "}
            backend.
          </p>
        </footer>
      </div>
    </div>
  );
}
